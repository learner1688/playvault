# VaultPlay Backend

Node.js + Express API for VaultPlay.
- Features: Game loader, token system, multiplayer, ads, leaderboard
- DB: PostgreSQL or MongoDB
