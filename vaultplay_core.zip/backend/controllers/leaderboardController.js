// Leaderboard controller
exports.getLeaderboard = (req, res) => {
  // ...return leaderboard data...
  res.json([]);
};
