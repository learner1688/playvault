// Auth controller: login, register, social
exports.login = (req, res) => {
  // ...handle login logic...
  res.json({ success: true });
};
exports.register = (req, res) => {
  // ...handle registration logic...
  res.json({ success: true });
};
exports.socialLogin = (req, res) => {
  // ...handle social login logic...
  res.json({ success: true });
};
