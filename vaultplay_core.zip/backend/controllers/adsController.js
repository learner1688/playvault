// Ads controller
exports.getBannerAd = (req, res) => {
  // ...return banner ad...
  res.json({ ad: null });
};
exports.getRewardedAd = (req, res) => {
  // ...return rewarded ad...
  res.json({ ad: null });
};
