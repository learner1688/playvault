// Tokens controller: earn, spend, sync
exports.earnTokens = (req, res) => {
  // ...handle earning tokens...
  res.json({ tokens: 0 });
};
exports.spendTokens = (req, res) => {
  // ...handle spending tokens...
  res.json({ tokens: 0 });
};
exports.syncTokens = (req, res) => {
  // ...sync tokens...
  res.json({ tokens: 0 });
};
