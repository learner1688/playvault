// Auth Page (Email + Social Login)
export default function Auth() {
  // Render login/register/social login forms
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Sign In / Register</h1>
      {/* Email login, Google/Facebook buttons */}
    </div>
  );
}
