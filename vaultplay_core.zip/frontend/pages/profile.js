// User Profile Page
export default function Profile() {
  // Fetch user tokens, games played, leaderboard rank
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Your Profile</h1>
      {/* Show tokens, games played, leaderboard rank */}
    </div>
  );
}
