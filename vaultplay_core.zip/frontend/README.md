# VaultPlay Frontend

This folder contains the Next.js web/mobile client for VaultPlay.
- Tech: Next.js, React, TailwindCSS, Framer Motion
- Features: Game grid, emulator player, responsive controllers, SEO, auth, profile, blog
