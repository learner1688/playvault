# Cloudflare R2 Storage Setup

- Store ROMs/ISOs in R2 bucket
- Use S3-compatible API for uploads/downloads
- Integrate with backend game loader
