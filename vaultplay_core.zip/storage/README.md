# VaultPlay Storage

Scripts and docs for uploading ROMs/ISOs to Cloudflare R2.
- Usage: Manage game files, CDN integration
